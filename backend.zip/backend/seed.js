// Café Moccha sample catalogue seed
// Run from the backend folder with: node seed.js
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Product = require('./api/modal/product.schema');

dotenv.config();

const standardSizes = [
  { name: 'Tall', extraPrice: 0 },
  { name: 'Grande', extraPrice: 30 },
  { name: 'Venti', extraPrice: 50 },
];
const coffeeMilks = ['Whole Milk', 'Oat Milk', 'Almond Milk', 'Soy Milk'];
const coffeeSyrups = [
  { name: 'Vanilla', extraPrice: 25 },
  { name: 'Caramel', extraPrice: 25 },
  { name: 'Hazelnut', extraPrice: 25 },
];

const sampleProducts = [
  // HOT COFFEE
  { name: 'Caffè Mocha', category: 'Hot Coffee', description: 'Rich espresso blended with bittersweet chocolate and silky steamed milk.', basePrice: 280, image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Cappuccino', category: 'Hot Coffee', description: 'A classic espresso topped with velvety steamed milk and airy foam.', basePrice: 230, image: 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Vanilla Latte', category: 'Hot Coffee', description: 'Smooth espresso and steamed milk with a delicate vanilla finish.', basePrice: 260, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Americano', category: 'Hot Coffee', description: 'Bold espresso mellowed with hot water for a clean, rich cup.', basePrice: 190, image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Caramel Macchiato', category: 'Hot Coffee', description: 'Espresso layered over vanilla milk and finished with caramel drizzle.', basePrice: 310, image: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: [{ name: 'Extra Caramel Drizzle', extraPrice: 30 }, ...coffeeSyrups] },
  // COLD COFFEE & FRAPPES
  { name: 'Classic Iced Latte', category: 'Cold Coffee', description: 'Chilled espresso and milk poured over ice for a refreshing pick-me-up.', basePrice: 250, image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Cold Brew', category: 'Cold Coffee', description: 'Slow-steeped coffee served chilled, smooth and naturally full-bodied.', basePrice: 270, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Java Chip Frappe', category: 'Frappes', description: 'A creamy blended coffee with chocolate chips and a rich mocha finish.', basePrice: 340, image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Caramel Crunch Frappe', category: 'Frappes', description: 'Blended coffee with caramel, creamy foam and a crunchy topping.', basePrice: 350, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Belgian Chocolate Frappe', category: 'Frappes', description: 'An indulgent chilled chocolate blend topped with a cocoa finish.', basePrice: 360, image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  // TEA & MORE
  { name: 'Masala Chai Latte', category: 'Tea & More', description: 'Comforting black tea with warming spices and steamed milk.', basePrice: 180, image: 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: [] },
  { name: 'Matcha Latte', category: 'Tea & More', description: 'Earthy green tea matcha whisked smooth with your choice of milk.', basePrice: 290, image: 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: [{ name: 'Vanilla', extraPrice: 25 }] },
  { name: 'Classic Hot Chocolate', category: 'Tea & More', description: 'Steamed milk and rich chocolate for a cosy, chocolatey treat.', basePrice: 240, image: 'https://images.unsplash.com/photo-1542990253-0b8be3a9f3f2?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: [] },
  // CAKES & DESSERTS
  { name: 'Chocolate Fudge Cake', category: 'Cakes & Desserts', description: 'Decadent chocolate sponge layered with silky fudge ganache.', basePrice: 220, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single Slice', extraPrice: 0 }, { name: 'Double Slice', extraPrice: 180 }], milkOptions: [], syrups: [] },
  { name: 'Red Velvet Cupcake', category: 'Cakes & Desserts', description: 'Soft red velvet sponge crowned with cream-cheese frosting.', basePrice: 120, image: 'https://images.unsplash.com/photo-1486427944299-d1955d23e34d?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single', extraPrice: 0 }, { name: 'Box of 4', extraPrice: 320 }], milkOptions: [], syrups: [] },
  { name: 'New York Cheesecake', category: 'Cakes & Desserts', description: 'Creamy baked cheesecake on a buttery biscuit base.', basePrice: 260, image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single Slice', extraPrice: 0 }, { name: 'Double Slice', extraPrice: 220 }], milkOptions: [], syrups: [] },
  { name: 'Chocolate Brownie', category: 'Cakes & Desserts', description: 'A fudgy chocolate brownie with a delicate crackly top.', basePrice: 150, image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single', extraPrice: 0 }, { name: 'With Ice Cream', extraPrice: 80 }], milkOptions: [], syrups: [] },
  // BAKERY & SNACKS
  { name: 'Butter Croissant', category: 'Bakery & Snacks', description: 'Golden, flaky pastry with delicate buttery layers.', basePrice: 140, image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single', extraPrice: 0 }, { name: 'Pack of 2', extraPrice: 120 }], milkOptions: [], syrups: [] },
  { name: 'Chocolate Croissant', category: 'Bakery & Snacks', description: 'Flaky baked pastry filled with rich chocolate.', basePrice: 170, image: 'https://images.unsplash.com/photo-1623334044303-241021148842?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Single', extraPrice: 0 }, { name: 'Pack of 2', extraPrice: 150 }], milkOptions: [], syrups: [] },
  { name: 'Classic Butter Cookies', category: 'Bakery & Snacks', description: 'Crisp, buttery cookies that pair perfectly with coffee.', basePrice: 110, image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Pack of 3', extraPrice: 0 }, { name: 'Pack of 6', extraPrice: 90 }], milkOptions: [], syrups: [] },
  { name: 'Truffle Cheese Sandwich', category: 'Savory Bites', description: 'Toasted sourdough with melted cheese and a fragrant truffle-style spread.', basePrice: 320, image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Regular', extraPrice: 0 }, { name: 'Combo with Coffee', extraPrice: 180 }], milkOptions: [], syrups: [] },
  { name: 'Pesto Paneer Panini', category: 'Savory Bites', description: 'Grilled panini filled with paneer, pesto and melted cheese.', basePrice: 290, image: 'https://images.unsplash.com/photo-1553909489-cd47e0ef937f?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Regular', extraPrice: 0 }, { name: 'Combo with Coffee', extraPrice: 180 }], milkOptions: [], syrups: [] },
  { name: 'Loaded Herb Fries', category: 'Savory Bites', description: 'Crispy fries tossed with herbs and a creamy house-style dip.', basePrice: 190, image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Regular', extraPrice: 0 }, { name: 'Large', extraPrice: 70 }], milkOptions: [], syrups: [] },
  // PREMIUM SIGNATURES
  { name: 'Pistachio Rose Latte', category: 'Premium Signatures', description: 'A fragrant signature latte with pistachio notes and a delicate rose finish.', basePrice: 380, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: [{ name: 'Extra Pistachio Cream', extraPrice: 45 }] },
  { name: 'Spanish Cream Latte', category: 'Premium Signatures', description: 'Bold espresso softened with sweet, silky cream for a café-style favourite.', basePrice: 360, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85', sizes: standardSizes, milkOptions: coffeeMilks, syrups: coffeeSyrups },
  { name: 'Affogato al Caffè', category: 'Premium Signatures', description: 'A scoop of vanilla ice cream finished with a fresh shot of espresso.', basePrice: 330, image: 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?auto=format&fit=crop&w=900&q=85', sizes: [{ name: 'Classic', extraPrice: 0 }, { name: 'Double Espresso', extraPrice: 60 }], milkOptions: [], syrups: [] },
];

mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/cafe_moccha')
  .then(async () => {
    await Product.deleteMany({});
    await Product.insertMany(sampleProducts.map((product) => ({ ...product, isAvailable: true })));
    console.log(`Database seeded successfully with ${sampleProducts.length} Café Moccha products!`);
    await mongoose.disconnect();
  })
  .catch(async (err) => {
    console.error('Seeding error:', err);
    await mongoose.disconnect().catch(() => {});
    process.exitCode = 1;
  });
