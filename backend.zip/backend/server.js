require('dotenv').config();
const app = require('./app');
const connectDB = require('./config/db');

const PORT = Number(process.env.PORT) || 5000;

async function start() {
  await connectDB();
  const server = app.listen(PORT, () => console.log(`Café Moccha API listening on port ${PORT}`));
  const shutdown = (signal) => {
    console.log(`${signal} received; shutting down gracefully`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

start().catch((error) => {
  console.error('Unable to start API:', error.message);
  process.exit(1);
});
