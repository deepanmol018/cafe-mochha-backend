// Backwards-compatible alias for the project's canonical Bearer-token middleware.
module.exports = require('../api/controller/middleware/auth.middleware');
