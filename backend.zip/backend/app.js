const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const authRoutes = require('./api/routes/auth.routes');
const productRoutes = require('./api/routes/product.routes');
const orderRoutes = require('./api/routes/order.routes');
const aiRoutes = require('./api/routes/ai.routes');
const notesRoutes = require('./api/routes/notesroutes');

const app = express();
app.disable('x-powered-by');
app.use(cors({
  origin(origin, callback) {
    const allowed = (process.env.CLIENT_ORIGIN || 'http://localhost:3000').split(',').map((v) => v.trim());
    if (!origin || allowed.includes(origin)) return callback(null, true);
    return callback(new Error('Origin not allowed by CORS'));
  },
  credentials: true,
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

// Small in-memory limit for auth endpoints. Use a shared store (e.g. Redis) for multi-instance production deployments.
const windows = new Map();
function authRateLimit(req, res, next) {
  const now = Date.now();
  const key = `${req.ip}:${req.baseUrl}`;
  const entry = windows.get(key);
  if (!entry || now - entry.startedAt > 15 * 60 * 1000) {
    windows.set(key, { startedAt: now, count: 1 });
    return next();
  }
  entry.count += 1;
  if (entry.count > 30) return res.status(429).json({ message: 'Too many authentication attempts. Try again later.' });
  return next();
}
app.use('/api/auth', authRateLimit, authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/notes', notesRoutes);

app.get('/api/health', (_req, res) => res.json({
  status: 'ok',
  database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
  timestamp: new Date().toISOString(),
}));
app.use((_req, res) => res.status(404).json({ message: 'API route not found' }));
app.use((err, _req, res, _next) => {
  console.error(err.stack || err);
  if (err.message === 'Origin not allowed by CORS') return res.status(403).json({ message: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'Invalid JSON request body' });
  res.status(err.status || 500).json({ message: process.env.NODE_ENV === 'production' ? 'Something went wrong' : err.message || 'Internal server error' });
});
module.exports = app;
