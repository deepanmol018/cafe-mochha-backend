const router = require('express').Router();
const auth = require('../controller/middleware/auth.middleware');
const { createOrder, verifyPayment, getMyOrders } = require('../controller/order.controller');
router.use(auth);
router.get('/my', getMyOrders);
router.post('/', createOrder);
router.post('/verify-payment', verifyPayment);
module.exports = router;
