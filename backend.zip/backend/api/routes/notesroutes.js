const router = require('express').Router();
const { getNotes } = require('../controller/notecontroller');

router.get('/', getNotes);

module.exports = router;