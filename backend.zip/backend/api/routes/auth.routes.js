const router = require('express').Router();
const { register, login, me } = require('../controller/auth.controller');
const auth = require('../controller/middleware/auth.middleware');
router.post('/register', register);
router.post('/login', login);
router.get('/me', auth, me);
module.exports = router;
