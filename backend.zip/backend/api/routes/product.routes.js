const router = require('express').Router();
const { getAllProducts, createProduct, updateProduct, deleteProduct } = require('../controller/product.controller');
const auth = require('../controller/middleware/auth.middleware');
const admin = require('../controller/middleware/admin.middleware');
router.get('/', getAllProducts);
router.post('/', auth, admin, createProduct);
router.patch('/:id', auth, admin, updateProduct);
router.delete('/:id', auth, admin, deleteProduct);
module.exports = router;
