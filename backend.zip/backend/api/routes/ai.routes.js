const router = require('express').Router();
const { getRecommendation } = require('../controller/ai.controller');

router.post('/recommend', getRecommendation);

module.exports = router;