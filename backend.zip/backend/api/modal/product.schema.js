const mongoose = require('mongoose');
const optionSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  extraPrice: { type: Number, default: 0, min: 0, max: 100000 },
}, { _id: false });
const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  category: { type: String, required: true, trim: true, maxlength: 80, index: true },
  description: { type: String, default: '', maxlength: 1000 },
  basePrice: { type: Number, required: true, min: 0, max: 100000 },
  image: { type: String, default: '' },
  sizes: { type: [optionSchema], default: [] },
  milkOptions: { type: [{ type: String, trim: true, maxlength: 80 }], default: [] },
  syrups: { type: [optionSchema], default: [] },
  isAvailable: { type: Boolean, default: true, index: true },
}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });
productSchema.index({ name: 'text', description: 'text', category: 'text' });
module.exports = mongoose.model('Product', productSchema);
