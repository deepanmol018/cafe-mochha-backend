const mongoose = require('mongoose');
const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name: { type: String, required: true },
    size: { type: String, default: '' },
    milk: { type: String, default: '' },
    syrups: { type: [String], default: [] },
    quantity: { type: Number, required: true, min: 1, max: 20 },
    price: { type: Number, required: true, min: 0 },
  }],
  totalAmount: { type: Number, required: true, min: 0 },
  razorpayOrderId: { type: String, index: true },
  razorpayPaymentId: String,
  status: { type: String, enum: ['Pending', 'Paid', 'Preparing', 'Completed', 'Cancelled'], default: 'Pending', index: true },
}, { timestamps: true });
module.exports = mongoose.model('Order', orderSchema);
