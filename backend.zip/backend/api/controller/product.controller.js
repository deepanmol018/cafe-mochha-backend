const mongoose = require('mongoose');
const Product = require('../modal/product.schema');

exports.getAllProducts = async (req, res, next) => {
  try {
    const page = Math.max(1, Math.min(10000, Number.parseInt(req.query.page, 10) || 1));
    const limit = Math.max(1, Math.min(50, Number.parseInt(req.query.limit, 10) || 24));
    const filter = {};
    if (typeof req.query.category === 'string' && req.query.category.trim()) filter.category = req.query.category.trim();
    if (typeof req.query.search === 'string' && req.query.search.trim()) {
      const escaped = req.query.search.trim().slice(0, 80).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filter.$or = [{ name: { $regex: escaped, $options: 'i' } }, { description: { $regex: escaped, $options: 'i' } }, { category: { $regex: escaped, $options: 'i' } }];
    }
    const [products, total] = await Promise.all([
      Product.find(filter).sort({ category: 1, name: 1 }).skip((page - 1) * limit).limit(limit).lean(),
      Product.countDocuments(filter),
    ]);
    return res.json({ products, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  } catch (error) { return next(error); }
};

exports.createProduct = async (req, res, next) => {
  try {
    const { name, category, basePrice } = req.body || {};
    if (typeof name !== 'string' || !name.trim() || name.trim().length > 120) return res.status(400).json({ message: 'Product name is required (max 120 characters)' });
    if (typeof category !== 'string' || !category.trim() || category.trim().length > 80) return res.status(400).json({ message: 'Product category is required' });
    if (!Number.isFinite(Number(basePrice)) || Number(basePrice) < 0 || Number(basePrice) > 100000) return res.status(400).json({ message: 'basePrice must be a valid non-negative amount' });
    const product = await Product.create({ ...req.body, name: name.trim(), category: category.trim(), basePrice: Number(basePrice) });
    return res.status(201).json({ product });
  } catch (error) { return next(error); }
};

exports.updateProduct = async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid product ID' });
    const allowed = ['name', 'category', 'description', 'basePrice', 'image', 'sizes', 'milkOptions', 'syrups'];
    const update = Object.fromEntries(Object.entries(req.body || {}).filter(([key]) => allowed.includes(key)));
    const product = await Product.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    return res.json({ product });
  } catch (error) { return next(error); }
};

exports.deleteProduct = async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid product ID' });
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    return res.json({ message: 'Product deleted' });
  } catch (error) { return next(error); }
};
