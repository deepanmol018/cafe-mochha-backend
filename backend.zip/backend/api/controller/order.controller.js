const crypto = require('crypto');
const mongoose = require('mongoose');
const Razorpay = require('razorpay');
const Order = require('../modal/order.schema');
const Product = require('../modal/product.schema');

function getRazorpay() {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return null;
  return new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
}

exports.createOrder = async (req, res, next) => {
  try {
    const items = req.body?.items;
    if (!Array.isArray(items) || items.length < 1 || items.length > 30) return res.status(400).json({ message: 'Provide between 1 and 30 order items' });
    const ids = [...new Set(items.map((item) => item.product))];
    if (ids.some((id) => !mongoose.isValidObjectId(id))) return res.status(400).json({ message: 'One or more products have invalid IDs' });
    const products = await Product.find({ _id: { $in: ids }, isAvailable: true }).lean();
    const byId = new Map(products.map((p) => [p._id.toString(), p]));
    if (byId.size !== ids.length) return res.status(400).json({ message: 'One or more products are unavailable' });
    let totalAmount = 0;
    const normalizedItems = [];
    for (const item of items) {
      const product = byId.get(String(item.product));
      const quantity = Number(item.quantity ?? 1);
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) return res.status(400).json({ message: 'Each quantity must be an integer from 1 to 20' });
      const size = product.sizes.find((s) => s.name === item.size);
      if (product.sizes.length && !size) return res.status(400).json({ message: `Invalid size for ${product.name}` });
      if (product.milkOptions.length && !product.milkOptions.includes(item.milk)) return res.status(400).json({ message: `Invalid milk option for ${product.name}` });
      const syrupNames = Array.isArray(item.syrups) ? [...new Set(item.syrups)] : [];
      const syrupOptions = syrupNames.map((name) => product.syrups.find((s) => s.name === name));
      if (syrupOptions.some((s) => !s)) return res.status(400).json({ message: `Invalid syrup option for ${product.name}` });
      const unitPrice = product.basePrice + (size?.extraPrice || 0) + syrupOptions.reduce((sum, syrup) => sum + syrup.extraPrice, 0);
      totalAmount += unitPrice * quantity;
      normalizedItems.push({ product: product._id, name: product.name, size: item.size || '', milk: item.milk || '', syrups: syrupNames, quantity, price: unitPrice });
    }
    if (totalAmount <= 0 || totalAmount > 1000000) return res.status(400).json({ message: 'Order total is outside the allowed range' });
    const razorpay = getRazorpay();
    if (!razorpay) return res.status(503).json({ message: 'Online checkout is not configured yet. Add Razorpay credentials to backend/.env.' });
    const paymentOrder = await razorpay.orders.create({ amount: Math.round(totalAmount * 100), currency: 'INR', receipt: `cafe_${Date.now()}` });
    const order = await Order.create({ user: req.user.id, items: normalizedItems, totalAmount, razorpayOrderId: paymentOrder.id });
    return res.status(201).json({ order, payment: { id: paymentOrder.id, amount: paymentOrder.amount, currency: paymentOrder.currency, keyId: process.env.RAZORPAY_KEY_ID } });
  } catch (error) { return next(error); }
};

exports.verifyPayment = async (req, res, next) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
    if (![razorpay_order_id, razorpay_payment_id, razorpay_signature].every((v) => typeof v === 'string' && v.length > 0)) return res.status(400).json({ message: 'Payment verification fields are required' });
    if (!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ message: 'Payment verification is not configured' });
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    const a = Buffer.from(expected); const b = Buffer.from(razorpay_signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).json({ message: 'Payment signature verification failed' });
    const order = await Order.findOneAndUpdate({ user: req.user.id, razorpayOrderId: razorpay_order_id }, { $set: { razorpayPaymentId: razorpay_payment_id, status: 'Paid' } }, { new: true });
    if (!order) return res.status(404).json({ message: 'Order not found for this account' });
    return res.json({ message: 'Payment verified', order });
  } catch (error) { return next(error); }
};

exports.getMyOrders = async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user.id }).sort({ createdAt: -1 }).limit(100).lean();
    return res.json({ orders });
  } catch (error) { return next(error); }
};
