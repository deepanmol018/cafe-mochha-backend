const moods = new Set(['energetic', 'relaxed', 'focused', 'adventurous', 'comforting']);
const preferences = new Set(['coffee', 'tea', 'cold', 'dairy-free', 'sweet']);
const recommendations = {
  energetic: { recommendation: 'Triple Shot Iced Espresso', reason: 'A bold, chilled pick for a high-energy day.' },
  relaxed: { recommendation: 'Vanilla Oat Milk Latte', reason: 'Smooth vanilla and oat milk make a mellow, comforting cup.' },
  focused: { recommendation: 'Americano', reason: 'A clean espresso-forward choice for a focused break.' },
  adventurous: { recommendation: 'Caramel Macchiato', reason: 'Layered espresso and caramel bring a little contrast to your cup.' },
  comforting: { recommendation: 'Caffè Mocha', reason: 'Chocolate and espresso make a rich, familiar treat.' },
};
exports.getRecommendation = async (req, res) => {
  const mood = typeof req.body?.mood === 'string' ? req.body.mood.toLowerCase() : '';
  const preference = typeof req.body?.preference === 'string' ? req.body.preference.toLowerCase() : 'coffee';
  if (!moods.has(mood)) return res.status(400).json({ message: `Choose a mood: ${[...moods].join(', ')}` });
  if (!preferences.has(preference)) return res.status(400).json({ message: `Choose a preference: ${[...preferences].join(', ')}` });
  let result = recommendations[mood];
  if (preference === 'tea') result = { recommendation: 'Vanilla Chai Latte', reason: 'A spiced tea-based option for your current mood.' };
  if (preference === 'cold') result = { recommendation: 'Caramel Macchiato (Iced)', reason: 'A chilled, layered drink that fits your preference.' };
  if (preference === 'dairy-free') result = { recommendation: 'Vanilla Oat Milk Latte', reason: 'A dairy-free-friendly suggestion; confirm ingredients with the café.' };
  if (preference === 'sweet') result = { recommendation: 'Caffè Mocha', reason: 'A chocolate-forward suggestion for a sweeter drink.' };
  return res.json({ ...result, mood, preference, generatedAt: new Date().toISOString() });
};
