const jwt = require('jsonwebtoken');

module.exports = function authenticate(req, res, next) {
  const header = req.get('authorization') || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return res.status(401).json({ message: 'Authentication required' });
  if (!process.env.JWT_SECRET) return res.status(500).json({ message: 'Server authentication is not configured' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.id, role: payload.role || 'customer' };
    return next();
  } catch (_error) {
    return res.status(401).json({ message: 'Session expired or token is invalid' });
  }
};
