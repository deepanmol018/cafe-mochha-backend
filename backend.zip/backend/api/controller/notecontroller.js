exports.getNotes = async (_req, res) => {
  // Notes storage is not implemented in the supplied project. Return an explicit empty collection instead of a misleading placeholder message.
  res.json({ notes: [], message: 'Notes API is ready; persistent note storage can be added when the note fields and ownership rules are defined.' });
};
